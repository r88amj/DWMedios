$(function(){
    $("#areaProject-tabs").responsiveTabs({
        animation:'slide'
    })
});