window.onload = function () {
    $('#loader').fadeOut();
    $('body').removeClass('hidden');
}